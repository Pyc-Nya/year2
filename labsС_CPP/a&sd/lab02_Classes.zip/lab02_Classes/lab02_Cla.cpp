#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "classes.hpp"

#define maxsize 13
template <typename type>
int Set<type>::size_un = 13;

template <typename type>
int Set<type>::cnt = 0;
const long q0 = 100000;

int main()
{
    srand(time(nullptr));
    Set<char> A('A'), B('B'), C('C'), D('D'), E;

    clock_t begin = clock();

    for (long i = 0; i <1000; i++)
    {
        E = (A & B & C) | D;
    }
    clock_t end = clock();

    E.print();

    std::cout << "Time: " << (double)(end - begin) / CLOCKS_PER_SEC << "s\n";
    return 0;
}